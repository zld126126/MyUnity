using System;

public class DoNotObfuscate : Attribute { }

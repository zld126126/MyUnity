Imports System

Public Class DoNotObfuscate
    Inherits System.Attribute

End Class

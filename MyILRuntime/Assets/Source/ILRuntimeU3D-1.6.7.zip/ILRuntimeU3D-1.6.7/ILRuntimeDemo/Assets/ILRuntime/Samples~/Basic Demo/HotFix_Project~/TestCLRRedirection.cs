﻿using System;
using System.Collections.Generic;

namespace HotFix_Project
{
    public class TestCLRRedirection
    {
        public static void RunTest()
        {
            UnityEngine.Debug.Log("看看这行的详细Log信息");
        }
    }
}

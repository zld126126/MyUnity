ILRuntime
==========
[![license](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/Ourpalm/ILRuntime/blob/master/LICENSE.TXT)
[![release](https://img.shields.io/badge/release-v1.6.3-blue.svg)](https://github.com/Ourpalm/ILRuntime/releases)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-blue.svg)](https://github.com/Ourpalm/ILRuntime/pulls)

[English Document](ReadMe-EN.md "Click here for English documents")

[中文在线文档](https://ourpalm.github.io/ILRuntime/)

[Unity Demo Project, Unity示例工程](https://github.com/Ourpalm/ILRuntimeU3D/)

QQ群：512079820
